import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import Projects from './pages/Projects';
import WorkOrders from './pages/WorkOrders';
import Vendors from './pages/Vendors';
import PurchaseOrders from './pages/PurchaseOrders';
import Inventory from './pages/Inventory';
import ActivityLog from './pages/ActivityLog';
import Bills from './pages/Bills';
import ProcessFlow from './pages/ProcessFlow';
import BOQ from './pages/BOQ';
import Indent from './pages/Indent';
import MeasurementBook from './pages/MeasurementBook';
import Milestones from './pages/Milestones';
import GRN from './pages/GRN';
import { RoleProvider, useRole } from './context/RoleContext';
import { ProjectProvider, useProject } from './context/ProjectContext';
import { UserCircle, Settings } from 'lucide-react';

const TopHeader = () => {
  const { role, setRole } = useRole();
  const { projects, activeProject, setActiveProject } = useProject();
  return (
    <div className="absolute top-0 right-0 p-6 z-50">
      <div className="flex items-center gap-3 bg-[#111113] border border-white/10 rounded-full px-4 py-2 shadow-lg">
        <Settings size={18} className="text-gray-400" />
        <span className="text-sm font-medium text-gray-400">Context:</span>
        <select 
          value={activeProject ? activeProject.id : ''} 
          onChange={(e) => setActiveProject(projects.find(p => p.id === parseInt(e.target.value)))}
          className="bg-transparent text-sm font-semibold text-white focus:outline-none cursor-pointer max-w-[200px] truncate"
        >
          {projects.map(p => (
            <option key={p.id} value={p.id} className="bg-[#111113]">{p.name}</option>
          ))}
        </select>
      </div>

      <div className="flex items-center gap-3 bg-[#111113] border border-white/10 rounded-full px-4 py-2 shadow-lg">
        <UserCircle size={18} className="text-gray-400" />
        <span className="text-sm font-medium text-gray-400">View as:</span>
        <select 
          value={role} 
          onChange={(e) => setRole(e.target.value)}
          className="bg-transparent text-sm font-semibold text-white focus:outline-none cursor-pointer"
        >
          <option value="Admin" className="bg-[#111113]">Admin 👑</option>
          <option value="Engineer" className="bg-[#111113]">Engineer 👷</option>
          <option value="Finance" className="bg-[#111113]">Finance 💼</option>
          <option value="Vendor" className="bg-[#111113]">Vendor 🏢</option>
        </select>
      </div>
    </div>
  );
};

function App() {
  return (
    <ProjectProvider>
      <RoleProvider>
        <Router>
          <div className="flex h-screen bg-[#09090b] text-white">
            <Sidebar />
            <main className="flex-1 overflow-y-auto p-8 pt-20 relative">
              <TopHeader />
              <Routes>
                <Route path="/" element={<Navigate to="/dashboard" replace />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/projects" element={<Projects />} />
                <Route path="/workorders" element={<WorkOrders />} />
                <Route path="/vendors" element={<Vendors />} />
                <Route path="/po" element={<PurchaseOrders />} />
                <Route path="/inventory" element={<Inventory />} />
                <Route path="/grn" element={<GRN />} />
                <Route path="/bills" element={<Bills />} />
                <Route path="/activity" element={<ActivityLog />} />
                <Route path="/flow" element={<ProcessFlow />} />
                <Route path="/boq" element={<BOQ />} />
                <Route path="/indent" element={<Indent />} />
                <Route path="/mb" element={<MeasurementBook />} />
                <Route path="/milestones" element={<Milestones />} />
              </Routes>
            </main>
          </div>
        </Router>
      </RoleProvider>
    </ProjectProvider>
  );
}

export default App;
