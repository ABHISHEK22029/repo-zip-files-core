import React, { useState, useEffect, useCallback, useMemo } from 'react';
import ReactFlow, { Background, Controls, MiniMap, applyNodeChanges, applyEdgeChanges, Panel } from 'reactflow';
import dagre from 'dagre';
import 'reactflow/dist/style.css';
import { Route, Info, X } from 'lucide-react';

const dagreGraph = new dagre.graphlib.Graph();
dagreGraph.setDefaultEdgeLabel(() => ({}));

const getLayoutedElements = (nodes, edges, direction = 'TB') => {
  const isHorizontal = direction === 'LR';
  dagreGraph.setGraph({ rankdir: direction });

  nodes.forEach((node) => {
    dagreGraph.setNode(node.id, { width: 200, height: 60 });
  });

  edges.forEach((edge) => {
    dagreGraph.setEdge(edge.source, edge.target);
  });

  dagre.layout(dagreGraph);

  nodes.forEach((node) => {
    const nodeWithPosition = dagreGraph.node(node.id);
    node.targetPosition = isHorizontal ? 'left' : 'top';
    node.sourcePosition = isHorizontal ? 'right' : 'bottom';
    node.position = {
      x: nodeWithPosition.x - 100,
      y: nodeWithPosition.y - 30,
    };
    return node;
  });

  return { nodes, edges };
};

const ProcessFlow = () => {
  const [nodes, setNodes] = useState([]);
  const [edges, setEdges] = useState([]);
  const [selectedNodeData, setSelectedNodeData] = useState(null);
  const [loading, setLoading] = useState(true);

  const onNodesChange = useCallback((changes) => setNodes((nds) => applyNodeChanges(changes, nds)), []);
  const onEdgesChange = useCallback((changes) => setEdges((eds) => applyEdgeChanges(changes, eds)), []);

  const onNodeClick = useCallback((event, node) => {
    setSelectedNodeData(node.data.details);
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [vendorsRes, poRes, billsRes] = await Promise.all([
          fetch('http://localhost:5000/vendors').then(res => res.json()),
          fetch('http://localhost:5000/po').then(res => res.json()),
          fetch('http://localhost:5000/bills').then(res => res.json())
        ]);

        const newNodes = [];
        const newEdges = [];

        // Add vendors
        vendorsRes.forEach(v => {
          newNodes.push({
            id: `v-${v.id}`,
            type: 'input',
            data: { label: `Vendor: ${v.name}`, details: { type: 'Vendor', name: v.name, sector: v.type, id: v.id } },
            style: { background: '#1e1e24', color: '#fff', border: '1px solid #4f46e5', borderRadius: '8px', padding: '10px 20px', width: 200 }
          });
        });

        // Add POs and link to vendors
        poRes.forEach(po => {
          newNodes.push({
            id: `po-${po.id}`,
            data: { label: `PO-${po.id}: ${po.itemName}`, details: { type: 'Purchase Order', id: po.id, item: po.itemName, quantity: po.quantity, status: po.status } },
            style: { background: '#1e1e24', color: '#fff', border: '1px solid #f59e0b', borderRadius: '8px', padding: '10px 20px', width: 200 }
          });
          newEdges.push({
            id: `e-v${po.vendorId}-po${po.id}`,
            source: `v-${po.vendorId}`,
            target: `po-${po.id}`,
            type: 'smoothstep',
            animated: true,
            style: { stroke: '#f59e0b' }
          });
        });

        // Add Bills and link to POs
        billsRes.forEach(bill => {
          newNodes.push({
            id: `b-${bill.id}`,
            type: 'output',
            data: { label: `RA Bill-${bill.id}`, details: { type: 'RA Bill', id: bill.id, gross: bill.grossAmount, net: bill.netAmount, status: bill.status } },
            style: { background: '#10b98120', color: '#10b981', border: '1px solid #10b981', borderRadius: '8px', padding: '10px 20px', width: 200 }
          });
          newEdges.push({
            id: `e-po${bill.poId}-b${bill.id}`,
            source: `po-${bill.poId}`,
            target: `b-${bill.id}`,
            type: 'smoothstep',
            animated: poRes.find(p => p.id === bill.poId)?.status === 'Delivered',
            style: { stroke: '#10b981' }
          });
        });

        // Layout the graph
        const layoutedElements = getLayoutedElements(newNodes, newEdges, 'LR');
        setNodes(layoutedElements.nodes);
        setEdges(layoutedElements.edges);
        setLoading(false);
      } catch (err) {
        console.error("Failed to load flow data", err);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 h-[calc(100vh-8rem)] flex gap-4">
      <div className="flex-1 bg-[#111113] border border-white/5 rounded-xl h-full w-full overflow-hidden relative">
        <div className="absolute top-4 left-4 z-10 bg-black/60 p-3 rounded-lg border border-white/10 backdrop-blur-md">
           <h1 className="text-xl font-semibold text-white/90 tracking-tight flex items-center gap-2">
            <Route className="text-indigo-400" />
            Dynamic Process Flow ({nodes.length} Nodes)
          </h1>
          <p className="text-gray-500 text-xs mt-1">Stressing the UI with massive connected data via Dagre auto-layout.</p>
        </div>
        
        {loading ? (
          <div className="h-full flex items-center justify-center text-gray-500">Loading flow data...</div>
        ) : (
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onNodeClick={onNodeClick}
            minZoom={0.1}
            fitView
            className="bg-black/50"
          >
            <Background color="#4f46e5" gap={20} size={1} opacity={0.1} />
            <Controls className="bg-[#1e1e24] border-white/10 fill-white" />
          </ReactFlow>
        )}
      </div>

      {selectedNodeData && (
        <div className="w-80 bg-[#111113] border border-white/5 rounded-xl h-full overflow-y-auto p-6 transition-all">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Info size={18} className="text-indigo-400" />
              Node Details
            </h2>
            <button onClick={() => setSelectedNodeData(null)} className="text-gray-500 hover:text-white">
              <X size={18} />
            </button>
          </div>
          
          <div className="space-y-4">
            {Object.entries(selectedNodeData).map(([key, value]) => (
              <div key={key} className="border-b border-white/5 pb-3">
                <p className="text-xs text-gray-500 uppercase tracking-wider mb-1">{key}</p>
                <p className="text-sm text-gray-200 font-medium">{value}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ProcessFlow;
