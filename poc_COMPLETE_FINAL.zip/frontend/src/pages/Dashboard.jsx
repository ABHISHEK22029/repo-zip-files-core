import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { LayoutDashboard, Users, ShoppingCart, CheckCircle, Package, AlertCircle, TrendingDown, Clock, Map as MapIcon, TrendingUp } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend, LineChart, Line, XAxis, YAxis, CartesianGrid, ReferenceLine } from 'recharts';
import { Link } from 'react-router-dom';
import ORRMap from '../components/ORRMap';
import { useProject } from '../context/ProjectContext';

const StatCard = ({ title, value, icon: Icon, colorClass }) => (
  <div className="bg-[#111113] border border-white/5 p-6 rounded-xl hover-lift">
    <div className="flex justify-between items-start mb-4">
      <div className="p-3 rounded-lg bg-white/5 text-white">
        <Icon size={24} className={colorClass} />
      </div>
    </div>
    <div>
      <p className="text-gray-400 text-sm font-medium mb-1">{title}</p>
      <h3 className="text-3xl font-bold text-white tracking-tight">{value}</h3>
    </div>
  </div>
);

const Dashboard = () => {
  const { activeProject } = useProject();
  const [stats, setStats] = useState({
    totalVendors: 0,
    totalPOs: 0,
    deliveredPOs: 0,
    inventoryCount: 0,
    distribution: [],
    insights: []
  });

  useEffect(() => {
    if(!activeProject) return;
    axios.get(`http://localhost:5000/dashboard?projectId=${activeProject.id}`)
      .then(res => setStats(res.data))
      .catch(err => console.error("Failed to fetch dashboard stats", err));
  }, [activeProject]);

  const COLORS = {
    'Pending': '#9ca3af',
    'Approved': '#60a5fa',
    'Dispatched': '#fbbf24',
    'Delivered': '#34d399'
  };

  const sCurveData = Array.from({length: 18}, (_, i) => {
    const x = (i - 9) / 3; 
    const planned = Math.round(100 / (1 + Math.exp(-x)));
    const actual = i <= 12 ? Math.max(0, planned - (Math.random() * 5 + 3)) : null;
    return { month: `M${i+1}`, Planned: planned, Actual: actual ? Math.round(actual) : null };
  });

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-7xl mx-auto space-y-8">
      <h1 className="text-2xl font-semibold text-white/90 tracking-tight">Executive Context: {activeProject?.name || 'Loading...'}</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Active Vendors" value={stats.totalVendors} icon={Users} colorClass="text-blue-400" />
        <StatCard title="Active POs" value={stats.totalPOs} icon={ShoppingCart} colorClass="text-indigo-400" />
        <StatCard title="Delivered POs" value={stats.deliveredPOs} icon={CheckCircle} colorClass="text-emerald-400" />
        <StatCard title="Inventory SKUs" value={stats.inventoryCount} icon={Package} colorClass="text-amber-400" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        <div className="bg-[#111113] border border-white/5 rounded-xl p-8 flex flex-col h-[400px]">
           <h2 className="text-lg font-medium text-white/90 mb-6 tracking-tight flex items-center gap-2">
              <TrendingUp size={18} className="text-blue-400" />
              S-Curve Status vs Master Plan
           </h2>
           <div className="flex-1 w-full">
              <ResponsiveContainer width="100%" height="100%">
                 <LineChart data={sCurveData} margin={{ top: 5, right: 20, left: -20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#222" />
                    <XAxis dataKey="month" stroke="#666" fontSize={12} tickLine={false} />
                    <YAxis stroke="#666" fontSize={12} tickLine={false} tickFormatter={(val) => `${val}%`} />
                    <Tooltip contentStyle={{ backgroundColor: '#111113', borderColor: 'rgba(255,255,255,0.1)' }} itemStyle={{ color: '#fff' }} />
                    <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                    <ReferenceLine x="M13" stroke="#ef4444" strokeDasharray="3 3" label={{ position: 'top', value: 'Today', fill: '#ef4444', fontSize: 12 }} />
                    <Line type="monotone" dataKey="Planned" stroke="#3b82f6" strokeWidth={2} strokeDasharray="5 5" dot={false} />
                    <Line type="monotone" dataKey="Actual" stroke="#10b981" strokeWidth={3} dot={{ r: 3, fill: '#10b981', strokeWidth: 0 }} />
                 </LineChart>
              </ResponsiveContainer>
           </div>
        </div>

        {activeProject?.type === 'construction' && (
          <div className="bg-[#111113] border border-white/5 rounded-xl p-8 flex flex-col h-[400px]">
             <h2 className="text-lg font-medium text-white/90 mb-6 tracking-tight flex items-center gap-2">
                <MapIcon size={18} className="text-emerald-400" />
                Live Deployment Map
             </h2>
             <div className="flex-1 w-full relative">
                <ORRMap />
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
