import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { formatDistanceToNow } from 'date-fns';
import { Activity } from 'lucide-react';

const ActivityLog = () => {
  const [activities, setActivities] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/activities')
      .then(res => setActivities(res.data))
      .catch(err => console.error("Failed to fetch activities", err));
  }, []);

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-semibold text-white/90 tracking-tight">Activity Timeline</h1>
          <p className="text-gray-500 text-sm mt-1">Immutable audit log of all system actions.</p>
        </div>
      </div>

      <div className="bg-[#111113] border border-white/5 p-8 rounded-xl relative">
        {activities.length > 0 ? (
           <div className="relative border-l border-white/10 ml-4 space-y-6">
             {activities.map((activity) => (
                <div key={activity.id} className="relative pl-8 table-row-animate group rounded-lg py-2">
                    <span className="absolute -left-2 top-3 w-4 h-4 rounded-full bg-blue-500/20 border border-blue-500 flex items-center justify-center">
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                    </span>
                    <div className="flex justify-between items-start">
                        <div>
                            <p className="text-white text-sm font-medium">{activity.description}</p>
                            <span className="inline-flex mt-1 items-center px-2 py-0.5 rounded text-[10px] font-medium bg-white/5 text-gray-400 border border-white/10 uppercase tracking-wider">
                                {activity.type}
                            </span>
                        </div>
                        <time className="text-xs text-gray-500 font-mono whitespace-nowrap">
                            {formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true })}
                        </time>
                    </div>
                </div>
             ))}
           </div>
        ) : (
            <div className="text-center text-gray-500 py-12 flex flex-col items-center">
                <Activity size={32} className="text-white/10 mb-3" />
                <p>No activity recorded yet.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default ActivityLog;
