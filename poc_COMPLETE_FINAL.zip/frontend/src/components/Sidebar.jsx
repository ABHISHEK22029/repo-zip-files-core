import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Users, ShoppingCart, Package, Activity, Receipt, Workflow, FileText, ClipboardList, BookOpen, Truck, FolderGit2, Briefcase } from 'lucide-react';
import { useRole } from '../context/RoleContext';
import { useProject } from '../context/ProjectContext';

const Sidebar = () => {
  const { role } = useRole();
  const { enabledModules } = useProject();

  const baseNavItems = [
    { name: 'Projects', path: '/projects', icon: <FolderGit2 size={20} /> },
    { name: 'Work Orders', path: '/workorders', icon: <Briefcase size={20} /> },
    { name: 'Dashboard', path: '/dashboard', icon: <LayoutDashboard size={20} /> },
    { name: 'Vendors', path: '/vendors', icon: <Users size={20} /> },
    { name: 'Purchase Orders', path: '/po', icon: <ShoppingCart size={20} /> },
    { name: 'GRN', path: '/grn', icon: <Truck size={20} /> },
    { name: 'Inventory', path: '/inventory', icon: <Package size={20} /> },
    { name: 'RA Bills', path: '/bills', icon: <Receipt size={20} /> },
    { name: 'Process Flow', path: '/flow', icon: <Workflow size={20} /> },
    { name: 'Activity Log', path: '/activity', icon: <Activity size={20} /> },
  ];

  const moduleNavItems = [
    { name: 'BOQ', path: '/boq', icon: <FileText size={20} />, requiredModule: 'BOQ' },
    { name: 'Indent', path: '/indent', icon: <ClipboardList size={20} />, requiredModule: 'Indent' },
    { name: 'Measurement Book', path: '/mb', icon: <BookOpen size={20} />, requiredModule: 'Measurement Book' },
    { name: 'Milestones', path: '/milestones', icon: <FileText size={20} />, requiredModule: 'Milestones' },
  ];

  // Combine base routing with enabled modules
  const allNavItems = [
    ...baseNavItems,
    ...moduleNavItems.filter((item) => enabledModules.includes(item.requiredModule))
  ];

  const getNavItemsForRole = () => {
    switch (role) {
      case 'Engineer':
        return allNavItems.filter(item => ['Purchase Orders', 'Inventory', 'RA Bills', 'Process Flow'].includes(item.name));
      case 'Finance':
        return allNavItems.filter(item => ['Dashboard', 'RA Bills', 'Activity Log'].includes(item.name));
      case 'Vendor':
        return allNavItems.filter(item => ['Purchase Orders'].includes(item.name));
      case 'Admin':
      default:
        return allNavItems;
    }
  };

  const navItems = getNavItemsForRole();

  return (
    <div className="w-64 bg-[#111113] border-r border-white/5 flex flex-col pt-8 font-medium">
      <div className="px-8 mb-10">
        <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-indigo-500 bg-clip-text text-transparent">Nexus Op</h1>
      </div>
      <nav className="flex-1 px-4 space-y-2">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive
                  ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20'
                  : 'text-gray-400 hover:text-white hover:bg-white/5 border border-transparent'
              }`
            }
          >
            {item.icon}
            {item.name}
          </NavLink>
        ))}
      </nav>
      <div className="p-8 text-xs text-gray-600">
        MVP v1.0
      </div>
    </div>
  );
};

export default Sidebar;
