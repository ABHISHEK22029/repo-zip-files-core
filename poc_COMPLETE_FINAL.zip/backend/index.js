const express = require('express');
const cors = require('cors');
const db = require('./db');

const projectController = require('./controllers/ProjectController');
const workOrderController = require('./controllers/WorkOrderController');
const billController = require('./controllers/BillController');

const grnRouter = require('./routes/grn');

const app = express();
app.use(cors());
app.use(express.json());

// Projects & Hierarchies
app.get('/projects', projectController.getProjects);
app.post('/projects', projectController.createProject);

app.get('/work-orders', workOrderController.getWorkOrders);
app.post('/work-orders', workOrderController.createWorkOrder);

app.get('/milestones', workOrderController.getMilestones);

// Operations with projectId filters
app.get('/vendors', (req, res) => {
    let query = "SELECT * FROM vendors";
    let params = [];
    if(req.query.projectId) { query += " WHERE projectId = ?"; params.push(req.query.projectId); }
    db.all(query, params, (err, rows) => res.json(rows));
});

app.get('/po', (req, res) => {
    let query = "SELECT * FROM purchase_orders";
    let params = [];
    if(req.query.projectId) { query += " WHERE projectId = ?"; params.push(req.query.projectId); }
    db.all(query, params, (err, rows) => res.json(rows));
});

app.get('/inventory', (req, res) => {
    let query = "SELECT * FROM inventory";
    let params = [];
    if(req.query.projectId) { query += " WHERE projectId = ?"; params.push(req.query.projectId); }
    db.all(query, params, (err, rows) => res.json(rows));
});

app.get('/boq', (req, res) => {
    let query = "SELECT * FROM boq_items";
    let params = [];
    if(req.query.projectId) { query += " WHERE projectId = ?"; params.push(req.query.projectId); }
    db.all(query, params, (err, rows) => res.json(rows));
});

app.post('/boq', (req, res) => {
    const { projectId, itemCode, description, unit, estimatedQuantity, rate } = req.body;
    db.run(`INSERT INTO boq_items (projectId, itemCode, description, unit, estimatedQuantity, rate) VALUES (?, ?, ?, ?, ?, ?)`, 
    [projectId, itemCode, description, unit, estimatedQuantity, rate], function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ id: this.lastID });
    });
});

app.get('/mb', (req, res) => {
    let query = "SELECT measurement_book.*, boq_items.itemCode FROM measurement_book LEFT JOIN boq_items ON measurement_book.boqId = boq_items.id";
    let params = [];
    if(req.query.projectId) { query += " WHERE measurement_book.projectId = ?"; params.push(req.query.projectId); }
    db.all(query, params, (err, rows) => res.json(rows));
});

app.post('/mb', (req, res) => {
    const { projectId, workOrderId, boqId, chainage, length, width, depth, measuredQuantity } = req.body;
    db.run(`INSERT INTO measurement_book (projectId, workOrderId, boqId, chainage, length, width, depth, measuredQuantity) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [projectId, workOrderId, boqId, chainage, length, width, depth, measuredQuantity], function(err){
        res.json({ id: this.lastID });
    });
});

app.get('/indent', (req, res) => {
    let query = "SELECT indents.*, boq_items.itemCode FROM indents LEFT JOIN boq_items ON indents.boqId = boq_items.id";
    let params = [];
    if(req.query.projectId) { query += " WHERE indents.projectId = ?"; params.push(req.query.projectId); }
    db.all(query, params, (err, rows) => res.json(rows));
});

app.post('/indent', (req, res) => {
    const { projectId, workOrderId, boqId, requestedQuantity, requiredDate, chainage } = req.body;
    db.run(`INSERT INTO indents (projectId, workOrderId, boqId, requestedQuantity, requiredDate, chainage, status) VALUES (?, ?, ?, ?, ?, ?, 'Pending')`,
    [projectId, workOrderId, boqId, requestedQuantity, requiredDate, chainage], function(err){
        res.json({ id: this.lastID });
    });
});

// GRN (Router module)
app.use('/grn', grnRouter);

// RA Bills (Controller dispatch)
app.get('/bills', billController.getBills);
app.post('/bills/generate', billController.generateRABill); // Triggered by UI button

// Dashboard Stats Helper
app.get('/dashboard', (req, res) => {
    const pid = req.query.projectId;
    // Basic mock stats for demo depending on projectId
    const stats = {
        totalVendors: pid ? 1 : 15,
        totalPOs: pid ? 2 : 30,
        deliveredPOs: pid ? 1 : 10,
        inventoryCount: pid ? 2 : 8,
        distribution: [{status: 'Pending', value: 2}, {status: 'Delivered', value: 1}],
        insights: pid ? ['Action required on WO-002'] : []
    };
    res.json(stats);
});

const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
